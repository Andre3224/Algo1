#Escreva um programa que lê um inteiro.
#Através de FUNÇÃO verifique e imprima se o número é positivo ou negativo. (L2.3).

def ehneg():
    if x > 0:
        print('É positivo!')
        
    elif x == 0:
        print('É nulo!')
    
    else:
        print('É negativo!')
        
    
x = int(input('Digite um valor: '))
ehneg()