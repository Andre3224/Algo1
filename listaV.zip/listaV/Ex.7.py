#Escreva um programa que lê um número inteiro. Através de uma FUNÇÃO verifique se o mesmo é par ou ímpar.
#Através de outra FUNÇÃO verifique se é positivo ou negativo.
#Ambas as funções devem RETORNAR o resultado para que seja impresso pelo programa principal (L2.8).

def poui():
    z = x%2
    
    if z == 0:
        print('É par!')
    else:
        print('É ímpar!')
        
def neg():
    if x >= 0:
        print('É positivo!')
    else:
        print('É negativo!')
        
x = int(input('Digite um número: '))

poui()
neg()