#Faça um programa em que o usuário informe o valor da venda e a condição de pagamento conforme o menu abaixo.
#Através de FUNÇÃO e CASE calcule o total da venda conforme condição de pagamento escolhida. Imprima total na função MAIN (L3.5):

x = float(input('Digite o valor da venda: '))

def avista():
    desc = 0.10
    result = x*desc
    preco = x-result
    print('O valor é: ', preco)

def vendap30():
    desc = 0.05
    result = x*desc
    preco = x-result
    npreco = preco/30
    print('O valor é (em 30 dias): ', npreco)
    
def vendap60():
    preco = x
    npreco = preco/60
    print('O valor é (em 60 dias): ', npreco)

def vendap90():
    acres = 0.05
    result = x*acres
    preco = x-result
    npreco = preco/90
    print('O valor é (em 90 dias): ', npreco)

def cartaocred():
    desc = 0.08
    result = x*desc
    preco = x-result
    print('O valor é (no cartão de crédito): ', preco)
    
def cartaodebt():
    desc = 0.07
    result = x*desc
    preco = x-result
   
    print('O valor é (no cartão de débito): ', preco)


op = 0
while op !=7:
    
    print('''
        [1] Venda a Vista - desconto de 10%
        [2] Venda a Prazo 30 dias - desconto de 5%
        [3] Venda a Prazo 60 dias - mesmo preço
        [4] Venda com cartão de crédito - desconto de 7%.
        [5] Venda com cartão de débito - desconto de 8%
        [6] Venda com cartão de crédito - desconto de 7%.
        [7] Sair''')
    
    op = int(input('Digite sua opção: '))
    
    if op == 1:
        avista()
        
    elif op == 2:
        vendap30()
        
    elif op == 3:
        vendap60()
        
    elif op == 4:
        vendap90()
        
    elif op == 5:
        cartaocred()
        
    elif op == 6:
        cartaodebt()
        
    else:
        print('Saindo ...')
        exit()