#Faça um programa que leia quatro notas obtidas por um aluno na disciplina de Cálculo.
#Através de FUNÇÃO calcule a média das notas. Através de uma segunda FUNÇÃO verifique a situação do aluno.
#Se a média for superior a 6 o aluno está aprovado, se a média estiver entre 5 e 5.9 aluno está em dependência;
#se a média for inferior a 5º aluno está reprovado.
#O resultado da situação do aluno deve ser RETORNADO para o programa principal e impresso para o usuário (L2.12).

def med():
    med = (w + x + y + z)/4
    print('A média é: ', med)
    global f
    f = float(med)

def dep():
    
    if f > 6:
        print('Aprovado!')
    
    elif 5 < f < 5.9:
        print('Está em dependência')
        
    else:
        print('Aluno Reprovado!')


w = float(input('Digite uma nota: '))
x = float(input('Digite outra nota: '))
y = float(input('Digite outra nota: '))
z = float(input('Digite outra nota: '))

med()
dep()