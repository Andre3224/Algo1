#Leia dois números reais e através de FUNÇÃO imprima e calcule: a soma, o produto, a divisão e a subtração entre eles.
#Cada operação matemática deve ser realizada por uma FUNÇÃO (L1.5).

def soma():
    som = x + y
    print('A soma é: ', som)
    
def produto():
    mult = x * y
    print('O produto é: ', mult)
    
def divisão():
    div = x/y
    rest = x%y
    print('A divisão é: ', div)
    print('O resto é: ', rest)

def subtração():
    sub = x-y
    print('A subtração é: ', sub)

x = float(input('Digite um valor (X): '))
y = float(input('Digite um velor (y): '))

soma()
produto()
divisão()
subtração()