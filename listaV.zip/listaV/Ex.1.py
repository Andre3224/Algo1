#Faça um programa para ler dois valores (x e y).
#Através de PROCEDIMENTO calcular x multiplicado por y e imprimir o resultado (L1.4).

def calcular():
    mult = x*y
    print('A multiplicação é: ', mult)

x= int(input('Digite o valor de x: '))
y= int(input('Digite o valor de y: '))

calcular()

